#!/usr/bin/env bash
set -e
echo "=========================================================="
echo " MIKO FINANCE - ANDROID APK DERLEME BETİĞİ (JDK 17 + SDK)"
echo "=========================================================="
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  echo "[!] UYARI: ANDROID_HOME tanımlı değil. Lütfen Android Studio veya Android Command-Line Tools kurulu ortamda çalıştırın."
  exit 1
fi
gradle assembleDebug
echo "[+] APK Başarıyla Derlendi: app/build/outputs/apk/debug/app-debug.apk"
