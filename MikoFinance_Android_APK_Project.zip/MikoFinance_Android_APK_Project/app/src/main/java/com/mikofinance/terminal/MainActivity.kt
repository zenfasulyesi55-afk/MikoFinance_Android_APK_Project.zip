package com.mikofinance.terminal

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(MikoNativeBridge(this), "MikoAndroidBridge")

        // Load the 100% standalone 35-agent MIKO FINANCE terminal from local APK assets
        webView.loadUrl("file:///android_asset/index.html")

        // Schedule periodic background sync within Android OS WorkManager limits (15 min)
        val syncWork = PeriodicWorkRequestBuilder<MikoSyncWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "MikoAutonomousSync",
            ExistingPeriodicWorkPolicy.KEEP,
            syncWork
        )
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}

class MikoNativeBridge(private val context: Context) {
    @JavascriptInterface
    fun getPlatformMode(): String {
        return "ANDROID_NATIVE_STANDALONE_NO_LLM"
    }
}
