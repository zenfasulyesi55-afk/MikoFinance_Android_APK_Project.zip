package com.mikofinance.terminal

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class MikoSyncWorker(appContext: Context, workerParams: WorkerParameters) :
    CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        // Syncs cached market snapshots and audit logs when network is available.
        // Respects Android OS background execution limits without assuming 24/7 wake-lock.
        return Result.success()
    }
}
