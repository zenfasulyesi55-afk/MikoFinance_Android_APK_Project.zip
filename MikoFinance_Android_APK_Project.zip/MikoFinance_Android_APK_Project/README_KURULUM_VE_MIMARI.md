# MIKO FINANCE — Bağımsız 35+ Ajanlı Finansal Algoritma Ekosistemi & Android APK Kılavuzu

## 1. Mimari Özeti ve Üretken Yapay Zekâdan (LLM) Tam Bağımsızlık
- Bu proje **Gemini, ChatGPT, Claude veya Grok gibi hiçbir üretken yapay zekâya bağımlı değildir**.
- Tüm analizler; `server_engine/miko_finance_engine.py` ve `app/src/main/assets/index.html` içerisindeki **saf matematiksel ve istatistiksel motor** (RSI, ATR, Z-Skoru, Bollinger Sıkışması, Hurst Üsteli, Pearson Korelasyon Matrisi, Parametrik VaR %95 ve 10.000x Monte Carlo) tarafından yürütülür.
- Mevcut 22 ajan (Mevcut BAŞKAN ve 5 alt uzmanı dahil) eksiksiz korunmuş; üstüne **Gerçek Başkan, Yükseliş Bekleyen, Bağımsız Denetçi, Haberci, Simülasyoncu, Teknik Grafikçi, Risk Yöneticisi, Likidite Uzmanı, Makroekonomi Uzmanı, Portföy Mimarı, Veri Doğrulama, Performans Denetçisi ve Anomali Araştırmacısı** olmak üzere 13 yeni uzman ajan entegre edilmiştir (Toplam 35 Ajan).

## 2. APK Derleme ve Telefona Kurulum Adımları
Bulut çalışma ortamında Android SDK (`android.jar`) bulunmadığından sahte/derlenmemiş bir dosya APK diye sunulmamıştır. APK dosyasını 2 yöntemle hemen üretebilirsiniz:

### Yöntem A: Bilgisayarınızda Android Studio / Gradle ile Derleme
1. `MikoFinance_Android_APK_Project.zip` arşivini klasöre çıkartın.
2. Android Studio ile klasörü açın veya terminalde `./build_apk.sh` (`gradle assembleDebug`) komutunu çalıştırın.
3. Üretilen `app/build/outputs/apk/debug/app-debug.apk` dosyasını telefonunuza atıp kurun.

### Yöntem B: Bilgisayarınıza Hiçbir Şey Kurmadan GitHub Actions ile Ücretsiz Bulutta APK Derleme
1. Bu klasörü ücretsiz bir GitHub deposuna (repository) yükleyin.
2. İçindeki `.github/workflows/build_android_apk.yml` dosyası otomatik çalışarak 2 dakika içinde `MikoFinance-v1.4.2-debug-apk` dosyasını derler ve **Actions -> Artifacts** altından indirmenizi sağlar.

### Yöntem C: Anında Kurulumsuz Mobil Uygulama (Standalone PWA)
- `app/src/main/assets/index.html` (veya doğrudan sunduğumuz `gemini_daytrading_agents_hub.html`) dosyasını telefonunuzda Chrome/Safari ile açıp **"Ana Ekrana Ekle"** diyerek tam ekran bağımsız uygulama olarak saniyeler içinde kullanabilirsiniz.
